"""Command-line entry point for AIDA-ReID."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from idm.engine import evaluate_main
if __name__ == "__main__":
    evaluate_main()

